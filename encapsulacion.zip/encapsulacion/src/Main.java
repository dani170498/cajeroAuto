import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

public class Main {
    public static void main(String[] args) {
        persona sujeto= new persona();
        sujeto.setNombre("Daniel Arteaga");
        sujeto.setEdad(24);
        sujeto.setTelefono(77220757);
        System.out.println(sujeto.getNombre());
        System.out.println(sujeto.getEdad());
        System.out.println(sujeto.getTelefono());
    }
}


class persona{
    //para el nombre
    private String nombre;
    public void setNombre(String nombre){
        this.nombre=nombre;

    }
    public String getNombre(){
        return this.nombre;

    }
    //para la edad
    private int edad;

    public void setEdad(int edad){
        this.edad=edad;

    }
    public int getEdad(){
        return this.edad;

    }
    //para el telefono
    private int telefono;
    public void setTelefono(int telefono){
        this.telefono=telefono;

    }
    public int getTelefono(){
        return this.telefono;
    }

}